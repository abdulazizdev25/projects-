"""
AI Student Performance Predictor
Beginner-friendly demo using sample (synthetic) student data.

Install:
    pip install pandas matplotlib scikit-learn

Run:
    python main.py
"""
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

DATA_FILE = "student_data.csv"
FEATURES = ["study_hours_per_day", "attendance_percent", "previous_score"]
TARGET = "final_score"

def main():
    # 1) DATA SCIENCE: load and inspect the sample dataset
    data = pd.read_csv(DATA_FILE)
    print("\nAI STUDENT PERFORMANCE PREDICTOR")
    print("-" * 36)
    print("\nFirst five sample rows:")
    print(data.head().to_string(index=False))
    print("\nAverage values:")
    print(data.mean(numeric_only=True).round(1).to_string())

    # Check for missing values before training
    if data[FEATURES + [TARGET]].isnull().any().any():
        raise ValueError("The dataset has missing values. Please clean it first.")

    # 2) MACHINE LEARNING: split examples into training and test sets
    X = data[FEATURES]
    y = data[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    # A simple, explainable machine-learning model
    model = LinearRegression()
    model.fit(X_train, y_train)

    # 3) EVALUATE the model on examples it did not train on
    predictions = model.predict(X_test)
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)
    print("\nModel evaluation on held-out sample data:")
    print(f"Mean Absolute Error (MAE): {mae:.2f} marks")
    print(f"R-squared (R²): {r2:.2f}")
    print("Note: these scores are only for this small synthetic demo dataset.")

    # 4) DATA VISUALIZATION: actual scores vs predicted scores
    plt.figure(figsize=(7, 5))
    plt.scatter(y_test, predictions)
    plt.xlabel("Actual sample score")
    plt.ylabel("Predicted score")
    plt.title("Actual vs Predicted Student Scores")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("prediction_plot.png", dpi=150)
    print("\nSaved chart as prediction_plot.png")

    # 5) Ask for a sample student and predict a score
    print("\nEnter sample student information to try a prediction.")
    try:
        hours = float(input("Study hours per day (0-24): "))
        attendance = float(input("Attendance percentage (0-100): "))
        previous = float(input("Previous score (0-100): "))
        if not (0 <= hours <= 24 and 0 <= attendance <= 100 and 0 <= previous <= 100):
            print("Please use values within the ranges shown.")
            return

        new_student = pd.DataFrame([{
            "study_hours_per_day": hours,
            "attendance_percent": attendance,
            "previous_score": previous
        }])
        result = float(model.predict(new_student)[0])
        result = max(0, min(100, result))
        print(f"\nEstimated final score: {result:.1f}/100")
        print("This is an estimate, not a guarantee or a judgement of a student.")
        print("Real predictions need larger, real, ethically collected data.")
    except ValueError:
        print("Please enter numbers only.")

if __name__ == "__main__":
    main()
