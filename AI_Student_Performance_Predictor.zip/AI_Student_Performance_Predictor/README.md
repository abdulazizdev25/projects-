# AI Student Performance Predictor

## What does it do?
This beginner project uses sample student data to:
1. Explore data and calculate averages (Data Science).
2. Train a Linear Regression machine-learning model (AI/ML).
3. Evaluate predictions with MAE and R-squared.
4. Draw an actual-vs-predicted chart.
5. Estimate a sample student's final score from three inputs.

## Important
`student_data.csv` is a small **synthetic demonstration dataset**, not real student records. Results are for learning only and must not be used to make decisions about real students.

## Requirements
- Python 3.9 or newer
- pandas
- matplotlib
- scikit-learn

Install dependencies:
```bash
pip install pandas matplotlib scikit-learn
```

## Run
Keep `main.py` and `student_data.csv` in the same folder, then run:
```bash
python main.py
```

## How to explain it in an interview
**Problem:** It can be difficult to see how study habits, attendance, and previous scores relate to final marks.

**Data Science part:** I inspect the dataset, calculate averages, check missing values, and visualize model predictions.

**AI/ML part:** I use Linear Regression to learn a relationship between study hours, attendance, previous score, and final score.

**Testing:** I split the data into training and test sets. MAE tells me the average size of the prediction error in marks. R-squared describes how well predictions match score variation on this test split.

**Limitation:** The data is small and synthetic, so it cannot prove how students perform in real life. A stronger version would need a larger, representative, ethically collected dataset and careful checks for bias.

## Be ready for these questions
- **Why Linear Regression?** It is a simple first model for predicting a number and is relatively easy to explain.
- **Why split training and test data?** To evaluate the model on examples it did not learn from.
- **What is MAE?** The average absolute difference between predicted and actual scores, measured in marks.
- **What is Data Science here?** Loading, checking, summarizing, and visualizing the data.
- **What is AI/ML here?** Training a model to make predictions from input features.
- **Is it ready for real schools?** No. It is a learning prototype using synthetic data.
